// mainwindow.cpp

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    // UI setup and window title
    ui->setupUi(this);
    setWindowTitle("RONDA GAME V0.1");

    // Apply stylesheet to all QPushButton within the main window
    this->setStyleSheet("QPushButton {"
                        "   color: white;"
                        "   border-image: url(:/new/prefix1/images/button.png) 5 15 5 15;"
                        "   border-top: 5px transparent;"
                        "   border-bottom: 5px transparent;"
                        "   border-right: 15px transparent;"
                        "   border-left: 15px transparent;"
                        "   min-width: 150px;"
                        "   min-height: 50px;"
                        "}");
}

MainWindow::~MainWindow() {
    // Destructor
    delete ui;
}

void MainWindow::on_pushButton_1_clicked() {
    // Create and show NameWindow when PLAY button is clicked
    namewindow = new NameWindow();
    namewindow->show();
    this->hide();
}

void MainWindow::on_pushButton_2_clicked() {
    // Create and show Rules window when RULES button is clicked
    rules = new Rules();
    rules->show();
}

void MainWindow::on_pushButton_3_clicked() {
    // Placeholder for SETTINGS button functionality
    // Add your implementation for the SETTINGS button here
}

