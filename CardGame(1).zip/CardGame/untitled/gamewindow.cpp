#include "gamewindow.h"
#include "ui_gamewindow.h"

#include "mainwindow.h"
#include "namewindow.h"

#include <QMessageBox>
#include <QtCore>
#include <QtGui>
#include <QString>
#include <QTextEdit>
#include"QMessageBox"
#include<QFile>
#include <QTextStream>
#include <QSharedMemory>



GameWindow::GameWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::GameWindow)
{
    ui->setupUi(this);
    setWindowState(Qt::WindowMaximized);
    setWindowTitle("RONDA GAME V0.1"); //Title


}

GameWindow::~GameWindow()
{
    delete ui;
}
