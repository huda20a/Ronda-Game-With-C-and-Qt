#include "playwwindow.h"
#include "table.h"
#include "ui_playwwindow.h"
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include "card.h"
#include "deck.h"
#include <iterator>
#include <vector>
#include "hand.h"
#include <QTime>
#include "scene.h"

// Function that gives a delay in ms
void delay(qreal delay)
{
    QTime dieTime = QTime::currentTime().addMSecs(delay);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10000);
}

// PlayWwindow constructor
PlayWwindow::PlayWwindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PlayWwindow)
{
    ui->setupUi(this);
    setWindowState(Qt::WindowMaximized);  // Set window to fullscreen
    setWindowTitle("Ronda Beta V0.4");    // Set title
    x = width();
    y = height();

    // Set up the main scene
    scene = new Scene();
    ui->graphicsView->setScene(scene);

    // Set up the background
    QGraphicsPixmapItem *background = new QGraphicsPixmapItem(QPixmap(":/new/prefix1/images/playBoard.png"));
    scene->addItem(background);
    background->setPos(QPointF(-background->boundingRect().width() / 2, -background->boundingRect().height() / 2));

    scene->setSceneRect(-x / 2, -y / 2, x, y); // Position of the scene, size
}

PlayWwindow::~PlayWwindow()
{
    delete ui;
}

// Function to call to start the game
void PlayWwindow::startgame()
{
    // Set up deck
    Deck *deck = new Deck(scene);

    // Set position of the deck
    deck->setPos(QPointF(-x * 0.425, 0) + QPointF(-deck->boundingRect().width() / 2, -deck->boundingRect().height() / 2));
    scene->addItem(deck);

    // Set up player/op hands
    hand = new Hand(scene);
    op = new Hand(scene);
    table = new Table(scene);

    deck->shuffle();   // Shuffle cards vector in the deck
    round(deck, hand, op); // Start round
}

// Function to call every round
void PlayWwindow::round(Deck *deck, Hand *hand, Hand *op)
{
    for (int i = 0; i < 4; i++)
    {
        hand->addCard(deck->drawCard());
        hand->cardsHand[i]->posAnimation->setStartValue(QPointF(-x * 0.425, 0) + QPointF(-hand->cardsHand[i]->boundingRect().width() / 2, -hand->cardsHand[i]->boundingRect().height() / 2));
        hand->cardsHand[i]->posAnimation->setEndValue(QPointF(-x * 0.175 + i * x * 0.116, y * 0.4) + QPointF(-hand->cardsHand[i]->boundingRect().width() / 2, -hand->cardsHand[i]->boundingRect().height() / 2));
        hand->cardsHand[i]->posAnimation->setDuration(500);
        hand->cardsHand[i]->setHand(1);
        scene->addItem(hand->cardsHand[i]);
        hand->cardsHand[i]->posAnimation->start();
    }

    for (int i = 0; i < 4; i++)
    {
        op->addCard(deck->drawCard());
        op->cardsHand[i]->posAnimation->setStartValue(QPointF(-x * 0.425, 0) + QPointF(-op->cardsHand[i]->boundingRect().width() / 2, -op->cardsHand[i]->boundingRect().height() / 2));
        op->cardsHand[i]->posAnimation->setEndValue(QPointF(-x * 0.175 + i * x * 0.116, -y * 0.4) + QPointF(-op->cardsHand[i]->boundingRect().width() / 2, -op->cardsHand[i]->boundingRect().height() / 2));
        op->cardsHand[i]->posAnimation->setDuration(500);
        scene->addItem(op->cardsHand[i]);
        op->cardsHand[i]->posAnimation->start();
    }

    delay(300);

    for (int i = 0; i < 4; i++)
    {
        hand->cardsHand[i]->flip();
    }

    playerturn();
    playerturn();
    playerturn();
    playerturn();
}

// Function to call to start player turn
void PlayWwindow::playerturn()
{
    scene->selectedCard = nullptr;
    while (scene->selectedCard == nullptr)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10000);
    scene->selectedCard->setZValue(41);

    if (table->checkCard(scene->selectedCard) != nullptr)
    {
        Card *foundCard = table->checkCard(scene->selectedCard);
        scene->selectedCard->startAnim(foundCard->pos(), 500);
        table->freePos(foundCard->pos() + QPointF(-foundCard->boundingRect().width() / 2, -foundCard->boundingRect().height() / 2));
        hand->dropCard(scene->selectedCard);
        table->dropCard(foundCard);

        Hand *playerCollected = new Hand(scene);
        playerCollected->addCard(foundCard);
        playerCollected->addCard(scene->selectedCard);

        delay(550);

        for (int i = scene->selectedCard->getNumber() + 1; i < 10; i++)
        {
            for (int j = 0; j < table->cardsHand.size(); j++)
            {
                if (table->cardsHand[j]->getNumber() == i)
                {
                    for (int k = 0; k < playerCollected->cardsHand.size(); k++)
                        playerCollected->cardsHand[k]->startAnim(table->cardsHand[j]->pos(), k * 100 + 400);
                    break;
                }
            }
        }
        scene->selectedCard->startAnim(QPointF(-x / 2, y / 2) + QPointF(0, y / 5), 700);
        foundCard->startAnim(QPointF(-x / 2, y / 2) + QPointF(0, y / 5), 600);
    }
    else
    {
        table->addCard(scene->selectedCard);
        hand->dropCard(scene->selectedCard);
        table->fillPos(table->emptyPos[0]);
        scene->selectedCard->startAnim(table->emptyPos[0] + QPointF(-scene->selectedCard->boundingRect().width() / 2, -scene->selectedCard->boundingRect().height() / 2), 500);
    }
}
