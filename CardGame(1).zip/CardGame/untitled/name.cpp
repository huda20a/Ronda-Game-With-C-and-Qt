#include "name.h"
#include "ui_name.h"
#include "mainwindow.h"
#include "QMessageBox"
#include <QFile>
#include<QTextStream>
#include <QSharedMemory>
#include <QString>
#include <QTextEdit>

Name::Name(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Name)
{
    ui->setupUi(this);
    ui->user_name->toPlainText() ;
}

Name::~Name()
{
    delete ui;
}


void Name::on_commencer_clicked()
{

}


