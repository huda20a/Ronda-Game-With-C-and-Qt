#include "playwindow.h"
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QTime>
#include "card.h"
#include "deck.h"
#include "hand.h"
#include "namewindow.h"
#include "scene.h"
#include "table.h"
#include "ui_playwindow.h"
#include <iterator>
#include <vector>

//function that give a delay in ms
void delay(qreal delay)
{
    QTime dieTime = QTime::currentTime().addMSecs(delay);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10000);
}

PlayWindow::PlayWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::PlayWindow)
{
    ui->setupUi(this);
    setWindowState(Qt::WindowMaximized);
    setWindowTitle("RONDA GAME V0.1"); //Title

    x = width();
    y = height();
    qInfo() << x;
    qInfo() << y;

    // set up the main scene
    scene = new Scene();
    ui->graphicsView->setScene(scene);
    scene->setSceneRect(-x / 2, -y / 2, x, y);
}

PlayWindow::~PlayWindow()
{
    delete ui;
}

//function to call to start the game
void PlayWindow::startgame()
{
    qInfo("Game started"); //game started info

    //set up deck
    Deck *deck = new Deck(scene);
    //set position of the deck
    deck->setPos(QPointF(-x * 0.425, 0)
                 + QPointF(-deck->boundingRect().width() / 2, -deck->boundingRect().height() / 2));
    scene->addItem(deck);

    //set up player/op hands
    hand = new Hand(scene);
    op = new Hand(scene);
    table = new Table(scene);

    deck->shuffle();       //shuffle cards vector in deck
    round(deck, hand, op); //start round
}

//fonction to call  every round
void PlayWindow::round(Deck *deck, Hand *hand, Hand *op)
{
    for (int i = 0; i < 4; i++) {        //get 4 radnom cards in player hand
        delay(300);                      //give a delay to draw each card
        hand->addCard(deck->drawCard()); //draw card from deck and add it to player's hand
        hand->cardsHand[i]->posAnimation->setStartValue(
            QPointF(-x * 0.425, 0)
            + QPointF(-hand->cardsHand[i]->boundingRect().width() / 2,
                      -hand->cardsHand[i]->boundingRect().height()
                          / 2)); //start card animation from deck position
        hand->cardsHand[i]->posAnimation->setEndValue(
            QPointF(-x * 0.175 + i * x * 0.116, y * 0.4)
            + QPointF(-hand->cardsHand[i]->boundingRect().width() / 2,
                      -hand->cardsHand[i]->boundingRect().height()
                          / 2)); //end card animation in the free positon in hand
        hand->cardsHand[i]->posAnimation->setDuration(500 + i * 100); //duration of animation
        hand->cardsHand[i]->setHand(1); //set the cards "whichHand" to 1=player hand
        scene->addItem(hand->cardsHand[i]);
        hand->cardsHand[i]->posAnimation->start(); // start the animation
    }

    delay(300); //delay between drawing cards for player and for op

    for (int i = 0; i < 4; i++) { //get 4 radnom cards in openent hand
        delay(300);
        op->addCard(deck->drawCard());
        op->cardsHand[i]->posAnimation->setStartValue(
            QPointF(-x * 0.425, 0)
            + QPointF(-op->cardsHand[i]->boundingRect().width() / 2,
                      -op->cardsHand[i]->boundingRect().height() / 2));
        op->cardsHand[i]->posAnimation->setEndValue(
            QPointF(-x * 0.175 + i * x * 0.116, -y * 0.4)
            + QPointF(-op->cardsHand[i]->boundingRect().width() / 2,
                      -op->cardsHand[i]->boundingRect().height() / 2));
        op->cardsHand[i]->posAnimation->setDuration(500 + i * 100);
        scene->addItem(op->cardsHand[i]);
        op->cardsHand[i]->posAnimation->start();
    }

    delay(300); //delay between drawing cards for op and flipping player cards

    for (int i = 0; i < 4; i++) //boucle to flip all player cards
    {
        delay(500);                 //delay betwee, flipping each card
        hand->cardsHand[i]->flip(); //flip card
    }

    //scene->itemAt(scene->lastclickedpos,QTransform())->setPos(100,0);
    playerturn(); //call playerturn function to start player turn
    playerturn();
    playerturn();
    playerturn();
}

//function to call to start player turn
void PlayWindow::playerturn()
{
    scene->selectedCard = nullptr;
    while (scene->selectedCard == nullptr) //keep the game stopped until the player select a card
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10000);
    scene->selectedCard->setZValue(41);

    if (table->checkCard(scene->selectedCard) != nullptr) {
        Card *foundCard = table->checkCard(scene->selectedCard);
        scene->selectedCard->startAnim(foundCard->pos(), 500);
        table->freePos(foundCard->pos()
                       + QPointF(-foundCard->boundingRect().width() / 2,
                                 -foundCard->boundingRect().height() / 2));
        hand->dropCard(scene->selectedCard);
        table->dropCard(foundCard);

        Hand *playerCollected = new Hand(scene);
        playerCollected->addCard(foundCard);
        playerCollected->addCard(scene->selectedCard);

        delay(550); //going up animation
        scene->selectedCard->startAnim(scene->selectedCard->pos() + QPointF(0, -25), 200);
        foundCard->startAnim(scene->selectedCard->pos() + QPointF(0, -50), 300);

        delay(350); //going down animation
        scene->selectedCard->startAnim(scene->selectedCard->pos() + QPointF(0, 25));
        foundCard->startAnim(foundCard->pos() + QPointF(0, 50));
        delay(350);

        for (int i = scene->selectedCard->getNumber() + 1; i < 10; i++) {
            for (int j = 0; j < table->cardsHand.size(); j++) {
                if (table->cardsHand[j]->getNumber() == i) {
                    for (int k = 0; k < playerCollected->cardsHand.size(); k++)
                        playerCollected->cardsHand[k]->startAnim(table->cardsHand[j]->pos(),
                                                                 k * 100 + 400);
                    break;
                }
            }
        }

        scene->selectedCard->startAnim(QPointF(-x / 2, y / 2) + QPointF(0, y / 5), 700);
        foundCard->startAnim(QPointF(-x / 2, y / 2) + QPointF(0, y / 5), 600);

    } else {
        table->addCard(scene->selectedCard);
        hand->dropCard(scene->selectedCard);
        table->fillPos(table->emptyPos[0]);
        scene->selectedCard->startAnim(table->emptyPos[0]
                                           + QPointF(-scene->selectedCard->boundingRect().width()
                                                         / 2,
                                                     -scene->selectedCard->boundingRect().height()
                                                         / 2),
                                       500);
    }

    qInfo() << "end" << table->emptyPos << "------" << table->usedPos;

    /*for(int i=0;i<table->emptyPos.size();i++)
    {   qInfo() << table->emptyPos[i];
        Card *n = new Card(scene->selectedCard);
        n->setpos(table->emptyPos[i]+QPointF(-n->boundingRect().width()/2,-n->boundingRect().height()/2));
        scene->addItem(n);
    }*/
}
