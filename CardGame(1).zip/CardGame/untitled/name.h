#ifndef NAME_H
#define NAME_H

#include <QWidget>
#include <QWidget>
#include <QString>
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class Name; }
QT_END_NAMESPACE

class Name : public QWidget
{
    Q_OBJECT

public:
    explicit Name(QWidget *parent = nullptr);
    ~Name();

private slots:
    void on_commencer_clicked();

private:
    Ui::Name *ui;
};

#endif // NAME_H
