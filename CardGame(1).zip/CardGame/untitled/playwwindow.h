#ifndef PLAYWWINDOW_H
#define PLAYWWINDOW_H

#include <QWidget>
#include <QGraphicsScene>
#include "deck.h"
#include "hand.h"
#include "scene.h"
#include "table.h"



namespace Ui {
class PlayWwindow;
}

class PlayWwindow : public QWidget
{
    Q_OBJECT

public:
    explicit PlayWwindow(QWidget *parent = nullptr);
    ~PlayWwindow();
    void startgame();
    void round(Deck *deck, Hand *hand, Hand *op);
    void playerturn();
    int x;
    int y;

private:
    Ui::PlayWwindow *ui;
    Scene *scene;
    Deck *deck;
    Hand *hand;
    Hand *op;
    Table *table;
};

#endif // PLAYWWINDOW_H
